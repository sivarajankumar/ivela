
function over(element) {
element.style.backgroundColor = "E3A309";
element.style.color = "#ffffff";
element.style.cursor = "hand";}

function out(element) {
element.style.backgroundColor = "F7BF24";
element.style.color = "#000000";
element.style.cursor = "default";}


function Mostrar(NumMenu) {
MenuFunc = eval('document.all.' + NumMenu + '.style');
state = MenuFunc.visibility;
if (state != "visible" || state != "show"){MenuFunc.visibility = "visible";}
}


function Sumir() {
document.all.Menu1.style.visibility = "hidden";
document.all.Menu2.style.visibility = "hidden";
document.all.Menu3.style.visibility = "hidden";
document.all.Menu4.style.visibility = "hidden";
document.all.Menu5.style.visibility = "hidden";
document.all.Menu6.style.visibility = "hidden";
document.all.Menu7.style.visibility = "hidden";
document.all.Menu8.style.visibility = "hidden";
document.all.Menu9.style.visibility = "hidden";
document.all.Menu10.style.visibility = "hidden";
document.all.Menu11.style.visibility = "hidden";
document.all.Menu12.style.visibility = "hidden";
document.all.Menu13.style.visibility = "hidden";
document.all.Menu14.style.visibility = "hidden";
document.all.Menu15.style.visibility = "hidden";
document.all.Menu16.style.visibility = "hidden";
document.all.Menu17.style.visibility = "hidden";
document.all.Menu18.style.visibility = "hidden";
document.all.Menu19.style.visibility = "hidden";
document.all.Menu20.style.visibility = "hidden";
}