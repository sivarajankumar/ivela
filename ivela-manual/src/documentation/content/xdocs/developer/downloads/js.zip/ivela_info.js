function showPlayer(sound) {
    var appletTag =
        "<applet code='br.ufc.ivela.voice.sound.PlayerApplet'" +
	"       archive='./applet/ivela_sound.jar," +
        "                ./applet/jogg-0.0.7.jar," +
        "                ./applet/jorbis-0.0.15.jar," +
        "                ./applet/tritonus_share.jar," +
        "                ./applet/vorbisspi1.0.3.jar'" +
        "       width='75' height='27'>" +
        "  <param name='audio_url' value='./audio/"+ sound +"' />" +
        "  <param name='audioHost' value='' />" +
        "</applet>";
    document.write(appletTag);
}

function playSound(){
     var sound = prompt("Sound:","");
     document.write("<bgsound src='"+sound+"' hidden=true/>");
}

// Displays image in page lesson
function showImage(){
	  var img = prompt("Image:","");
          var tag_page =  '<img src="'+ img +'" width="300" height="300" />';
          document.write(tag_page);
}

function ProgressCourse()
{
  var progress = getUserProgress();
  var j = 0;

  var did =  '<img src="images/home_andamento_feito.gif" alt="" />';
  var didnt = '<img src="images/home_andamento_falta.gif" alt="" />';
  var cont = 0;

  for(j=0 ; j < 10 ; j++){
       if(j < progress)
       {
         document.write(did);
         cont += 11;
       }
       else{document.write(didnt);}
  }
}

function showImageModuloFig(){

   var mod_alt = "Modulo ";
   var resp = "1";
   var imag_mod = "";
    /*
   do{
     resp = prompt("Modulo sendo cursado:","");}
   while(resp == " "|| resp == "" || resp == null);
      */
   imag_mod = '<img src="images/modulo_' + resp + '_icone.png" width="80" height="80"/>';
   document.write(imag_mod);

}

function showImageNumberModuloFig(){

   var mod_alt = "Modulo ";
   var resp = "1";
   var imag_mod = "";
    /*
   do{
     resp = prompt("Modulo sendo cursado:","");}
   while(resp == " "|| resp == "" || resp == null || (resp >= 4 && resp <= 0));
      */
   imag_mod = '<img src="images/modulos_tit_'+resp+'.png" />';
   document.write(imag_mod);

}

function translateWord(keyWord){
     var width = 500;
     var height = 450;
     var left = 50;
     var top = 50;
     var url = "http://www.google.com/dictionary?aq=f&langpair=en|pt&q="+keyWord+"&hl=pt-BR";
     window.open(url,'janela','width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');
}