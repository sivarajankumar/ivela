//Comentarios em portugues sao itens q podem ser modificados!!!!

/***************************************************************************************************/
/* List of JS functions to be used to load lessons' and user data inside HTML pages in content     */
/* packages.                                                                                       */
/* (Course developer version)                                                                      */
/***************************************************************************************************/

/***************************************************************************************************/
/* User information related functions:                                                             */
/* (These functions load data needed used to display user information when s/he clicks on "Status" */
/* button.)                                                                                        */
/***************************************************************************************************/

// Funcao que chama o quadro de status do usuario (talvez ela ja esteja contida no template)
function showStatus(){
         window.alert("Normal");
}

// Gets user name value from ivela
function getUserName(){
         var name = "John Doe";
         return name;
}

// Displays user name from Ivela
function displayUserName(){
         document.write(getUserName());
}

// Gets user progress value from Ivela
function getUserProgress(){
         return 9;
}

// Gets time remaining value
function getTimeRemaining(){
         var tempo = 50;
         if(tempo < 2){document.write(tempo+" hora");}
         else{document.write(tempo+" horas");}
}

/***************************************************************************************************/
/* Lesson layout related functions:                                                                */
/* (These functions are used to help users to build HTML                                           */
/***************************************************************************************************/

// Goes to previous page
function previousPage(){
         var pg = "";

         do{
             pg =prompt("P�gina:","http://");}
         while(pg == "http://" || pg == "http:// " || pg == null);

         window.location.href  = pg;
}

// Goes to next page
function nextPage(){
         var pg ="";

         do{
             pg =prompt("P�gina:","http://");}
         while(pg == "http://" || pg == "http:// " || pg == null);

         window.location.href  = pg;
}

// Goes to selected page - this function will be used
function goToPage(namePage){
          /*var pg ="S:/Rio_Bacuri/Ivela_conteudo/CursoIngles/Unidade1/Templates/templates_atualizacao 3/site_html/"+namePage;*/
          var pg = namePage;
          window.location.href  = pg;
}

function goToDiscipline(discipline) {
}
// Plays sound file

/***************************************************************************************************/
/* Lessons and Modules permissions functions                                                       */
/***************************************************************************************************/


// Check lesson permission
function checkLessonPermission( ){
   window.alert("Permitido");
}

// Check Module permission
function checkModulePermission(module, unit, lesson){
   window.alert("Permitido");
}


function isCompleted(module, unit, lesson){
    var text = "";
    if(module != null){ text += "Module ";}
    if(unit != null){ text += "Unit ";}
    if(lesson != null){ text += "Lesson ";}
    window.alert(text);
}

function isInProgress(module, unit, lesson){
    var text = "";
    if(module != null){ text += "Module ";}
    if(unit != null){ text += "Unit ";}
    if(lesson != null){ text += "Lesson ";}
    window.alert(text);
}

// This function gets student score value from Ivela
function getScore(){
          var score = 1;
          if(score < 2){document.write(score+" Ponto");}
          else{document.write(score+" Pontos");}
}


function getCourseCredits(){
    document.write(10);
}

// After completing each exercise, the student will click on "Submit" button.
// Then, submitExercise() is called to send users aswers to Ivela
function submitExercise(){
   window.alert("Exercicio Submetido com Sucesso!!!");
     var errorPop = document.getElementById('error_popup');
     if(errorPop) errorPop.style.visibility = 'visible';
  }


/* Retrieves the Right Answers for the Exercise, this will mark the exercise as done */
function getExerciseAnswers(form) {    
    return false;
}

function redoExercise(form) {
    return false;
}

function closePopUpError() {
     var errorPop = document.getElementById('error_popup');
     if(errorPop) errorPop.style.visibility = 'hidden';
}


// Gets student's answers in challenges
function getQuestionAnswers(id_field){
         return;
}

// Compares student's answer with correct answers and return status  - right or wrong
function checkQuestions(answer){
         return;
}

// Displays icon related do status of question - right or wrong
function printStatusQuestions(id_field){
         return;
}


/***************************************************************************************************/
/* Ivela general features related functions                                                        */
/***************************************************************************************************/

// Displays Media Library
function mediaLibrary(){
         window.alert("In Ivela, MediaLibrary should be loaded by now...");
}

// Displays Forum
function displayForum(){
         //window.alert("In Ivela, Forum should be loaded by now...");
         var pg = "";
            if(pg == "http://" || pg == "http:// " || pg == null) {

            }
         do{
             pg =prompt("P�gina:","http://");}
         while(pg == "http://" || pg == "http:// " || pg == null);

         window.open(pg);
}

// Displays Chat
function displayChat(){
         
         var pg = "";

         do{
             pg =prompt("P�gina:","http://");}
         while(pg == "http://" || pg == "http:// " || pg == null);

         window.open(pg);
}

// Displays Tutor
function displayTutor(){
      
      var daReferrer = document.referrer;
      var email = "EMAIL@email.com";
      var msg_erro = "CASO HAJA ALGUM ERRO COLOQUE AQUI E ADICIONE NO LINK";
      var assunto = "[IVELA] ASSUNTO";
      //var body_message = "%0D%0D%0D%0DThank you "+name+" for submitting this error to us. Please tell us in the space above, what you were doing when the error occurred.%0D%0DReferring Page: "+daReferrer+" %0D%0DException Error Message:%0D-------------------------------------------%0D"+errorMsg;
      var corpo_msg = "Escreva aqui sua mensagem.";
      var mailto_link = 'mailto:'+email+'?subject='+assunto+'&body='+corpo_msg;

      var win = window.open(mailto_link,'emailWindow');
      if (win && win.open &&!win.closed) win.close();

}

//[Dicionary] Show and Hide
function ShowAndHideDicionary(){
         var dicionary_visible = document.getElementById("busca");
         if(dicionary_visible.style.visibility == "hidden"){dicionary_visible.style.visibility = "visible";}
         else{dicionary_visible.style.visibility = "hidden";}
}

//[Status] Show and Hide
function ShowAndHideStatus(){
         var status_visible = document.getElementById("status");
         if(status_visible.style.visibility == "hidden"){status_visible.style.visibility = "visible";}
         else{status_visible.style.visibility = "hidden";}
}

//Close the window
function fechar(){window.close();}

function getLessonNumber(){

     var imag_mod = "";

   /*do{
     resp = prompt("N�mero da Li��o:","");}
   while(resp == " "|| resp == "" || resp == null || (resp >= 4 && resp <= 0));*/
   document.write("12");

}

function computeUrl(url) {
}
function computeExe(exe) {
}